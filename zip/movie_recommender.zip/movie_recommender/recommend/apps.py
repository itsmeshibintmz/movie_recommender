from django.apps import AppConfig


class RecommendConfig(AppConfig):
    name = 'recommend'
